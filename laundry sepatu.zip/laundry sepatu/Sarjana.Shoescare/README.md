# Kinclong Sepatu — Prototype Microservice

Versi microservice dari website laundry sepatu. Backend yang tadinya satu server dipecah menjadi 5 layanan kecil dan 1 API gateway. **Frontend tidak berubah** (alamat API-nya sama), dan tidak perlu `npm install` karena semua kode hanya memakai bawaan Node.js.

## Arsitektur

```
 Browser
    │
    ▼
┌────────────────────────┐
│ API Gateway  :8080     │  sajikan frontend, routing, cek token admin,
│                        │  rate limit, agregasi, health check
└─┬────┬────┬────┬────┬──┘
  │    │    │    │    │
  ▼    ▼    ▼    ▼    ▼
catalog order review auth notification
:4001  :4002 :4003  :4004 :4005
  ▲      │                     ▲
  └──────┤  (1) minta harga    │
         └─────────────────────┘  (2) kirim event (async)
```

| Layanan | Port | Tanggung jawab | Data sendiri |
|---|---|---|---|
| **gateway** | 8080 | Satu-satunya pintu dari browser; routing; verifikasi token admin; statistik gabungan | - |
| **catalog** | 4001 | Daftar layanan, harga, promo, perhitungan biaya | `data/catalog.json` |
| **order** | 4002 | Buat pesanan, lacak, kelola pesanan (admin) | `data/order.json` |
| **review** | 4003 | Ulasan pelanggan, rata-rata nilai | `data/review.json` |
| **auth** | 4004 | Login admin, token bertanda tangan HMAC | - (stateless) |
| **notification** | 4005 | Terima event, buat pesan WhatsApp (simulasi) | `data/notification.json` |

Konsep microservice yang didemonstrasikan:
- **Database per layanan**: tiap layanan hanya menyentuh file datanya sendiri.
- **Komunikasi sinkron**: Order memanggil Catalog untuk menghitung harga (klien tidak bisa memalsukan harga).
- **Komunikasi asinkron (event)**: Order mengirim `order.created` / `order.status_changed` ke Notification tanpa menunggu hasilnya.
- **Ketahanan**: kalau Notification mati, pesanan tetap masuk. Kalau Review mati, dashboard admin tetap tampil. Kalau Catalog mati, pesanan ditolak dengan pesan 503 yang rapi.
- **API composition**: `/api/admin/stats` di gateway menggabungkan data Order dan Review.
- **Keamanan internal**: layanan menolak akses langsung (403) tanpa kunci internal, jadi hanya bisa dipanggil lewat gateway.
- **Penelusuran**: setiap request punya `x-request-id` yang sama di log gateway dan layanan.

## Menjalankan (Windows / Mac / Linux)

Butuh **Node.js 18+** (cek: `node -v`).

```bash
cd kinclong-microservices
node start-all.js        # atau: npm start
```

Lalu buka **http://localhost:8080**. Halaman admin: **http://localhost:8080/admin.html** (kata sandi `admin123`).
Hentikan dengan `Ctrl + C`. Data tersimpan di folder `data/` (dibuat otomatis).

Mengubah kata sandi dan kunci (disarankan):
```powershell
# PowerShell
$env:ADMIN_PASSWORD="sandi-kuat"; $env:AUTH_SECRET="rahasia-panjang"; $env:INTERNAL_KEY="kunci-internal"; node start-all.js
```

Menjalankan satu layanan saja (untuk eksperimen), misalnya di terminal terpisah:
```bash
PORT=4001 node services/catalog/index.js
```

## Mencoba ketahanan sistem
1. Jalankan semua layanan, buka halaman admin dan lihat bagian **Status layanan** (semua hijau).
2. Matikan satu layanan (misalnya tutup proses `notification`, atau jalankan layanan satu per satu dan hentikan salah satunya).
3. Muat ulang admin: layanan itu berwarna merah, tetapi layanan lain tetap bekerja.
4. Buat pesanan baru: tetap berhasil walau Notification mati. Di admin, bagian **Notifikasi WhatsApp** menampilkan pesan yang dibuat otomatis saat pesanan masuk atau statusnya diubah.

Cek kesehatan lewat browser: `http://localhost:8080/api/health`.

## Docker (opsional)
```bash
docker compose up --build
```
Hanya gateway (`:8080`) yang terbuka ke luar; layanan lain hanya bisa dijangkau lewat jaringan internal Docker. Ganti nilai `INTERNAL_KEY`, `AUTH_SECRET`, dan `ADMIN_PASSWORD` di `docker-compose.yml` sebelum dipakai serius.

## Endpoint (lewat gateway)
| Method | Path | Layanan |
|---|---|---|
| GET | `/api/health` | gateway (cek semua layanan) |
| GET | `/api/services` | catalog |
| POST | `/api/quote` | catalog |
| POST | `/api/orders` | order (memanggil catalog, memicu notification) |
| GET | `/api/orders/:code` | order |
| GET, POST | `/api/testimonials` | review |
| POST | `/api/admin/login` | auth |
| GET | `/api/admin/stats` | gateway: order + review |
| GET | `/api/admin/orders` | order (token) |
| PATCH, DELETE | `/api/admin/orders/:code` | order (token) |
| GET | `/api/admin/notifications` | notification (token) |

## Struktur folder
```
kinclong-microservices/
├── start-all.js            jalankan semua layanan sekaligus
├── docker-compose.yml, Dockerfile
├── shared/lib.js           mini framework HTTP, pemanggil antar-layanan, penyimpanan JSON
├── services/
│   ├── gateway/index.js
│   ├── catalog/index.js
│   ├── order/index.js
│   ├── review/index.js
│   ├── auth/index.js
│   └── notification/index.js
└── frontend/               index.html, admin.html, style.css, api.js, app.js
```

## Batasan prototype (yang perlu diganti untuk produksi)
- Penyimpanan file JSON per layanan: ganti dengan database sungguhan (PostgreSQL/MongoDB), satu per layanan.
- Event dikirim lewat HTTP langsung dan hilang kalau Notification sedang mati. Untuk produksi, pakai message broker (RabbitMQ, Redis Streams, Kafka) supaya event antre dan diulang.
- `shared/lib.js` dipakai bersama demi kesederhanaan. Pada sistem besar, tiap layanan biasanya punya kode mandiri.
- Notifikasi WhatsApp hanya simulasi. Sambungkan ke WhatsApp Business API, Fonnte, atau Twilio di `services/notification/index.js`.
- Rate limit ada di memori gateway; pakai Redis kalau gateway dijalankan lebih dari satu instance.
- Pasang HTTPS (misalnya Caddy atau Nginx di depan gateway).
