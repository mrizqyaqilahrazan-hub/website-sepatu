'use strict';
/*
 * API Gateway (port 8080): satu-satunya pintu masuk dari browser.
 *  - Menyajikan frontend statis
 *  - Meneruskan /api/* ke layanan yang tepat
 *  - Memverifikasi token admin lewat Auth Service sebelum meneruskan /api/admin/*
 *  - Menggabungkan data beberapa layanan (statistik admin) dan mengecek kesehatan semua layanan
 *  - Pembatas laju (rate limit) per IP dan ID permintaan (x-request-id) untuk penelusuran log
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URLS, INTERNAL_KEY, call, HttpError, readBody } = require('../../shared/lib');

const PORT = process.env.PORT || 8080;
const FRONTEND = path.resolve(process.env.FRONTEND_DIR || path.join(__dirname, '..', '..', 'frontend'));
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json'
};

// Peta rute: awalan path -> layanan tujuan
const ROUTES = [
  { prefix: '/api/services', target: 'catalog' },
  { prefix: '/api/quote', target: 'catalog' },
  { prefix: '/api/orders', target: 'order' },
  { prefix: '/api/testimonials', target: 'review' },
  { prefix: '/api/admin/login', target: 'auth' },
  { prefix: '/api/admin/orders', target: 'order', admin: true },
  { prefix: '/api/admin/notifications', target: 'notification', admin: true }
];
const matchRoute = p => ROUTES.find(r => p === r.prefix || p.startsWith(r.prefix + '/'));

/* ---------- Rate limit sederhana: 120 permintaan / menit / IP ---------- */
const hits = new Map();
function rateLimit(ip) {
  const now = Date.now();
  let h = hits.get(ip);
  if (!h || h.reset < now) { h = { n: 0, reset: now + 60000 }; hits.set(ip, h); }
  if (++h.n > 120) throw new HttpError(429, 'Terlalu banyak permintaan. Coba lagi sebentar lagi.');
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (v.reset < now) hits.delete(k); }, 60000).unref();

/* ---------- Pemeriksaan kesehatan semua layanan ---------- */
async function health() {
  const names = Object.keys(URLS);
  const results = await Promise.all(names.map(async n => {
    const t = Date.now();
    try { await call(URLS[n], 'GET', '/health', { timeout: 1500 }); return [n, { ok: true, ms: Date.now() - t }]; }
    catch { return [n, { ok: false }]; }
  }));
  return { gateway: { ok: true }, services: Object.fromEntries(results), all_ok: results.every(([, v]) => v.ok) };
}

/* ---------- Agregasi: statistik admin dari Order + Review ---------- */
async function adminStats(headers) {
  const [orders, reviews] = await Promise.allSettled([
    call(URLS.order, 'GET', '/admin/stats', { headers }),
    call(URLS.review, 'GET', '/stats', { headers })
  ]);
  if (orders.status === 'rejected') throw orders.reason;
  // Kalau Review Service mati, dashboard tetap tampil (nilai ulasan kosong)
  return { ...orders.value, avg_rating: reviews.status === 'fulfilled' ? reviews.value.avg_rating : null };
}

/* ---------- Meneruskan request ke layanan ---------- */
async function proxy(req, res, target, url, rid, ip) {
  const raw = await readBody(req);
  const headers = {
    'content-type': req.headers['content-type'] || 'application/json',
    'x-internal-key': INTERNAL_KEY, 'x-request-id': rid, 'x-forwarded-for': ip
  };
  let r;
  try {
    r = await fetch(URLS[target] + url.pathname.replace(/^\/api/, '') + url.search, {
      method: req.method, headers,
      body: ['GET', 'HEAD', 'DELETE'].includes(req.method) ? undefined : raw,
      signal: AbortSignal.timeout(5000)
    });
  } catch {
    throw new HttpError(503, `Layanan ${target} sedang tidak tersedia. Coba lagi nanti.`);
  }
  const text = await r.text();
  res.writeHead(r.status, { 'content-type': r.headers.get('content-type') || 'application/json', 'content-length': Buffer.byteLength(text) });
  res.end(text);
}

async function requireAdmin(req, rid) {
  await call(URLS.auth, 'POST', '/verify', { headers: { authorization: req.headers.authorization || '', 'x-request-id': rid } });
}

/* ---------- File statis ---------- */
async function serveStatic(pathname, res) {
  let rel = decodeURIComponent(pathname);
  if (rel.endsWith('/')) rel += 'index.html';
  const file = path.normalize(path.join(FRONTEND, rel));
  if (!file.startsWith(FRONTEND)) throw new HttpError(403, 'Dilarang.');
  try {
    const data = await fs.promises.readFile(file);
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' });
    res.end(data);
  } catch {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    res.end('Halaman tidak ditemukan.');
  }
}

/* ---------- Server ---------- */
const server = http.createServer(async (req, res) => {
  const t0 = Date.now();
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  const rid = crypto.randomBytes(4).toString('hex');
  const ip = req.socket.remoteAddress || 'unknown';

  res.setHeader('access-control-allow-origin', '*');
  res.setHeader('access-control-allow-headers', 'content-type, authorization');
  res.setHeader('access-control-allow-methods', 'GET, POST, PATCH, DELETE, OPTIONS');
  res.setHeader('x-request-id', rid);
  res.on('finish', () => { if (req.method !== 'OPTIONS') console.log(`[gateway] ${req.method} ${p} ${res.statusCode} ${Date.now() - t0}ms ${rid}`); });

  const json = (s, d) => {
    const b = JSON.stringify(d);
    res.writeHead(s, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(b) });
    res.end(b);
  };

  try {
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

    if (p === '/api' || p.startsWith('/api/')) {
      rateLimit(ip);
      if (p === '/api/health') return json(200, await health());
      if (p === '/api/admin/stats' && req.method === 'GET') {
        await requireAdmin(req, rid);
        return json(200, await adminStats({ 'x-request-id': rid }));
      }
      const route = matchRoute(p);
      if (!route) throw new HttpError(404, 'Endpoint tidak ditemukan.');
      if (route.admin) await requireAdmin(req, rid);
      return await proxy(req, res, route.target, url, rid, ip);
    }

    await serveStatic(p, res);
  } catch (e) {
    const s = e.status || 500;
    if (s === 500) console.error('[gateway]', e);
    json(s, { error: s === 500 ? 'Terjadi kesalahan di server.' : e.message });
  }
});

server.listen(PORT, () => console.log(`[gateway] siap di http://localhost:${PORT}`));
