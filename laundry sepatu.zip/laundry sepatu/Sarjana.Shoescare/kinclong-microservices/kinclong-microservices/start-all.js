'use strict';
/* Menjalankan semua layanan sekaligus (untuk pengembangan lokal). Hentikan dengan Ctrl+C. */
const { spawn } = require('child_process');
const path = require('path');

const SERVICES = [
  ['catalog', 4001], ['order', 4002], ['review', 4003],
  ['auth', 4004], ['notification', 4005], ['gateway', Number(process.env.GATEWAY_PORT) || 8080]
];

const children = SERVICES.map(([name, port]) => {
  const child = spawn(process.execPath, [path.join(__dirname, 'services', name, 'index.js')], {
    env: { ...process.env, PORT: String(port) }, stdio: 'inherit'
  });
  child.on('exit', code => { if (!stopping) console.log(`[start-all] layanan ${name} berhenti (kode ${code})`); });
  return child;
});

let stopping = false;
function stop() {
  if (stopping) return;
  stopping = true;
  console.log('\n[start-all] menghentikan semua layanan...');
  children.forEach(c => c.kill());
  setTimeout(() => process.exit(0), 300);
}
process.on('SIGINT', stop);
process.on('SIGTERM', stop);

setTimeout(() => console.log('\n>>> Buka http://localhost:' + (Number(process.env.GATEWAY_PORT) || 8080) + '  (admin: /admin.html)\n'), 800);
