/* Logika halaman utama Kinclong Sepatu */
const $ = (s, r = document) => r.querySelector(s);
const form = $('#orderForm');
let services = [];
let offline = false;

/* Daftar cadangan: dipakai kalau backend belum berjalan (harus sama dengan data di server) */
const FALLBACK_SERVICES = [
  { id: 1, name: 'Fast Clean', price: 25000, days: 1, description: 'Bagian luar dan sol untuk noda ringan.' },
  { id: 2, name: 'Deep Clean', price: 45000, days: 2, description: 'Upper, midsole, insole, dan tali dicuci menyeluruh.' },
  { id: 3, name: 'Suede & Leather Care', price: 65000, days: 3, description: 'Perawatan kulit dan suede dengan bahan khusus.' },
  { id: 4, name: 'Unyellowing', price: 55000, days: 3, description: 'Mengembalikan midsole yang menguning.' },
  { id: 5, name: 'Repaint & Reglue', price: 85000, days: 5, description: 'Cat ulang bagian pudar dan lem sol yang lepas.' },
  { id: 6, name: 'Cuci Tas & Topi', price: 35000, days: 2, description: 'Tas ransel, tote bag, dan topi dicuci dengan hati-hati.' },
  { id: 7, name: 'Anti-Bau & Disinfeksi', price: 20000, days: 1, description: 'Tambahan: hilangkan bau dan bakteri di dalam sepatu.' }
];

function localQuote(serviceId, qty, pickup, promo) {
  const s = services.find(x => x.id === serviceId);
  if (!s || !Number.isInteger(qty) || qty < 1 || qty > 20) return null;
  const subtotal = s.price * qty;
  const pickup_fee = pickup ? (subtotal >= 100000 ? 0 : 10000) : 0;
  const promo_valid = promo.trim().toUpperCase() === 'KINCLONG10';
  const discount = promo_valid ? Math.round(subtotal * 0.1) : 0;
  return { subtotal, pickup_fee, discount, promo_valid, total: subtotal - discount + pickup_fee, days: s.days };
}

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
}
function setMsg(node, text, type) {
  node.textContent = text || '';
  node.className = 'msg' + (type ? ' ' + type : '');
}

/* ---------- Slider sebelum / sesudah ---------- */
$('#ba').addEventListener('input', e => {
  $('#stage').style.setProperty('--pos', e.target.value + '%');
});

/* ---------- Layanan ---------- */
async function loadServices() {
  const list = $('#serviceList');
  try {
    services = await api('/api/services');
  } catch (e) {
    services = FALLBACK_SERVICES;
    offline = true;
  }
  list.replaceChildren();
  if (offline) {
    list.append(el('li', 'empty', 'Backend belum terhubung, jadi daftar ini versi bawaan. Jalankan server Node/Python agar pesanan bisa dikirim.'));
  }
  const select = $('#service_id');
  services.forEach(s => {
    const li = el('li');
    const row = el('div', 'row');
    row.append(el('span', 'name', s.name), el('span', 'leader'), el('span', 'price', rupiah(s.price)));
    const sub = el('div', 'sub');
    const left = el('div');
    left.append(el('p', 'desc', s.description), el('p', 'eta', 'Estimasi ' + s.days + ' hari kerja'));
    const pick = el('button', 'btn small ghost', 'Pilih');
    pick.type = 'button';
    pick.addEventListener('click', () => {
      select.value = s.id;
      scheduleQuote();
      location.hash = '#pesan';
      $('#name').focus({ preventScroll: true });
    });
    sub.append(left, pick);
    li.append(row, sub);
    list.append(li);

    const opt = el('option', '', s.name + ' — ' + rupiah(s.price));
    opt.value = s.id;
    select.append(opt);
  });
}

/* ---------- Estimasi biaya (dihitung server) ---------- */
let quoteTimer;
function scheduleQuote() { clearTimeout(quoteTimer); quoteTimer = setTimeout(updateQuote, 200); }

async function updateQuote() {
  const serviceId = Number(form.service_id.value);
  if (!serviceId) { renderQuote(null); return; }
  if (offline) {
    const q = localQuote(serviceId, Number(form.qty.value), form.pickup.checked, form.promo.value);
    renderQuote(q, q ? '' : 'Jumlah sepatu harus 1 sampai 20 pasang.');
    return;
  }
  try {
    const q = await api('/api/quote', {
      method: 'POST',
      body: { service_id: serviceId, qty: Number(form.qty.value), pickup: form.pickup.checked, promo: form.promo.value }
    });
    renderQuote(q);
  } catch (e) {
    renderQuote(null, e.message);
  }
}

function renderQuote(q, err) {
  $('#sumList').hidden = !q;
  $('#sumEmpty').hidden = !!q;
  if (!q) { $('#sumEmpty').textContent = err || 'Pilih layanan untuk melihat perkiraan.'; $('#q-eta').textContent = ''; return; }
  $('#q-sub').textContent = rupiah(q.subtotal);
  $('#q-pick').textContent = form.pickup.checked ? (q.pickup_fee === 0 ? 'Gratis' : rupiah(q.pickup_fee)) : '-';
  $('#q-disc').textContent = q.discount ? '-' + rupiah(q.discount) : (form.promo.value && !q.promo_valid ? 'Kode tidak berlaku' : '-');
  $('#q-total').textContent = rupiah(q.total);
  $('#q-eta').textContent = 'Selesai sekitar ' + q.days + ' hari kerja setelah sepatu kami terima.';
}

['service_id', 'qty', 'pickup', 'promo'].forEach(n => {
  form[n].addEventListener(n === 'promo' || n === 'qty' ? 'input' : 'change', scheduleQuote);
});
form.pickup.addEventListener('change', () => {
  $('#addrWrap').hidden = !form.pickup.checked;
  form.address.required = form.pickup.checked;
});

/* ---------- Kirim pesanan ---------- */
const getCodes = () => { try { return JSON.parse(localStorage.getItem('ks_codes')) || []; } catch { return []; } };
function saveCode(code) {
  try { localStorage.setItem('ks_codes', JSON.stringify([code, ...getCodes().filter(c => c !== code)].slice(0, 5))); } catch { /* storage nonaktif */ }
  renderMyCodes();
}

form.addEventListener('submit', async e => {
  e.preventDefault();
  const msg = $('#orderMsg');
  if (!form.checkValidity()) { form.reportValidity(); return; }
  const btn = $('#submitBtn');
  btn.disabled = true;
  setMsg(msg, 'Mengirim pesanan…');
  try {
    const order = await api('/api/orders', {
      method: 'POST',
      body: {
        name: form.name.value, phone: form.phone.value, service_id: Number(form.service_id.value),
        qty: Number(form.qty.value), shoe_type: form.shoe_type.value, pickup: form.pickup.checked,
        address: form.address.value, promo: form.promo.value, notes: form.notes.value
      }
    });
    setMsg(msg, 'Pesanan berhasil dikirim. Total ' + rupiah(order.total) + '.', 'ok');
    $('#resCode').textContent = order.code;
    $('#orderResult').hidden = false;
    saveCode(order.code);
    form.reset();
    $('#addrWrap').hidden = true;
    form.address.required = false;
    renderQuote(null);
  } catch (err) {
    setMsg(msg, err.message, 'err');
  } finally {
    btn.disabled = false;
  }
});

$('#copyCode').addEventListener('click', async () => {
  const code = $('#resCode').textContent;
  try { await navigator.clipboard.writeText(code); $('#copyCode').textContent = 'Tersalin'; }
  catch { $('#copyCode').textContent = 'Salin manual: ' + code; }
});

/* ---------- Lacak pesanan ---------- */
function renderMyCodes() {
  const box = $('#myCodes');
  box.replaceChildren();
  getCodes().forEach(code => {
    const b = el('button', '', code);
    b.type = 'button';
    b.addEventListener('click', () => { $('#trackCode').value = code; track(code); });
    box.append(b);
  });
}

async function track(code) {
  const msg = $('#trackMsg');
  $('#trackResult').hidden = true;
  setMsg(msg, 'Mencari…');
  try {
    const o = await api('/api/orders/' + encodeURIComponent(code.trim().toUpperCase()));
    setMsg(msg, '');
    $('#tName').textContent = o.name;
    $('#tService').textContent = o.service_name + ' ×' + o.qty;
    $('#tTotal').textContent = rupiah(o.total);
    const steps = STATUSES.filter(s => o.pickup || s !== 'Dijemput');
    const idx = steps.indexOf(o.status);
    const tl = $('#timeline');
    tl.replaceChildren();
    steps.forEach((s, i) => {
      const li = el('li', i < idx ? 'done' : i === idx ? 'now' : '', s);
      const h = o.history.find(x => x.status === s);
      if (h) li.append(el('small', '', fmtTime(h.at)));
      tl.append(li);
    });
    $('#trackResult').hidden = false;
  } catch (e) {
    setMsg(msg, e.message, 'err');
  }
}
$('#trackForm').addEventListener('submit', e => { e.preventDefault(); track($('#trackCode').value); });

/* ---------- Ulasan ---------- */
async function loadReviews() {
  const list = $('#reviewList');
  try {
    const items = await api('/api/testimonials');
    list.replaceChildren();
    if (!items.length) { list.append(el('li', 'empty', 'Belum ada ulasan. Jadilah yang pertama.')); return; }
    items.forEach(t => {
      const li = el('li');
      li.append(el('span', 'who', t.name + ' '), el('span', 'stars', '★'.repeat(t.rating) + '☆'.repeat(5 - t.rating)), el('p', '', t.message));
      list.append(li);
    });
  } catch (e) {
    list.replaceChildren(el('li', 'empty', e.message));
  }
}

$('#reviewForm').addEventListener('submit', async e => {
  e.preventDefault();
  const msg = $('#reviewMsg');
  try {
    await api('/api/testimonials', {
      method: 'POST',
      body: { name: $('#rName').value, rating: Number($('#rRating').value), message: $('#rMsg').value }
    });
    setMsg(msg, 'Terima kasih atas ulasanmu.', 'ok');
    e.target.reset();
    loadReviews();
  } catch (err) {
    setMsg(msg, err.message, 'err');
  }
});

/* ---------- Mulai ---------- */
$('#year').textContent = new Date().getFullYear();
renderMyCodes();
loadServices();
loadReviews();
