/*
 * Helper pemanggil API (dipakai index.html dan admin.html).
 * Secara default memanggil server yang sama (relatif "/api/...").
 * Kalau frontend dibuka dari tempat lain, tambahkan ?api=http://alamat-gateway
 */
// Kalau halaman dibuka langsung dari file (file://), arahkan ke gateway di localhost:8080.
// Untuk backend Python gunakan ?api=http://alamat-gateway
const API_BASE = (new URLSearchParams(location.search).get('api') || window.API_BASE ||
  (location.protocol === 'file:' ? 'http://localhost:8080' : '')).replace(/\/$/, '');

const STATUSES = ['Diterima', 'Dijemput', 'Dicuci', 'Dikeringkan', 'Siap diambil', 'Selesai'];

async function api(path, { method = 'GET', body, token } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  let res;
  try {
    res = await fetch(API_BASE + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch {
    throw new Error('Tidak bisa terhubung ke server. Pastikan backend sudah berjalan.');
  }
  let data = null;
  try { data = await res.json(); } catch { /* respons kosong */ }
  if (!res.ok) {
    const err = new Error((data && data.error) || 'Terjadi kesalahan (' + res.status + ')');
    err.status = res.status;
    throw err;
  }
  return data;
}

const rupiah = n => 'Rp' + Number(n).toLocaleString('id-ID');
const fmtTime = iso => new Date(iso).toLocaleString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
