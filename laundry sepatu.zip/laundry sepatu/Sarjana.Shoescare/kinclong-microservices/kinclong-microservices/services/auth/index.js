'use strict';
/*
 * Auth Service (port 4004): login admin dan verifikasi token.
 * Token bertanda tangan HMAC (mirip JWT sederhana), jadi tetap valid walau layanan ini restart.
 */
const crypto = require('crypto');
const { createApp, HttpError } = require('../../shared/lib');

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const SECRET = process.env.AUTH_SECRET || 'dev-auth-secret-ganti-di-produksi';
const TTL = 8 * 60 * 60 * 1000;
const attempts = new Map(); // ip -> { count, until }
const app = createApp('auth');

const hmac = data => crypto.createHmac('sha256', SECRET).update(data).digest('base64url');
const sha = v => crypto.createHash('sha256').update(String(v)).digest();

function sign(payload) {
  const p = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return p + '.' + hmac(p);
}
function verify(token) {
  const [p, sig] = String(token || '').split('.');
  if (!p || !sig) return null;
  const a = Buffer.from(sig), b = Buffer.from(hmac(p));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  const data = JSON.parse(Buffer.from(p, 'base64url').toString());
  return data.exp > Date.now() ? data : null;
}

app.post('/admin/login', ({ body, headers }) => {
  const ip = String(headers['x-forwarded-for'] || 'unknown');
  const a = attempts.get(ip);
  if (a && a.until > Date.now() && a.count >= 5) throw new HttpError(429, 'Terlalu banyak percobaan. Coba lagi beberapa menit lagi.');
  if (!crypto.timingSafeEqual(sha(body.password || ''), sha(ADMIN_PASSWORD))) {
    const cur = a && a.until > Date.now() ? a : { count: 0 };
    attempts.set(ip, { count: cur.count + 1, until: Date.now() + 10 * 60 * 1000 });
    throw new HttpError(401, 'Kata sandi salah.');
  }
  attempts.delete(ip);
  return { token: sign({ sub: 'admin', exp: Date.now() + TTL }), expires_in: TTL / 1000 };
});

// Dipanggil gateway sebelum meneruskan request /api/admin/*
app.post('/verify', ({ headers }) => {
  const m = /^Bearer (.+)$/.exec(headers.authorization || '');
  const data = m && verify(m[1]);
  if (!data) throw new HttpError(401, 'Tidak diizinkan. Silakan masuk lagi.');
  return { valid: true, sub: data.sub };
});

app.listen(process.env.PORT || 4004);
