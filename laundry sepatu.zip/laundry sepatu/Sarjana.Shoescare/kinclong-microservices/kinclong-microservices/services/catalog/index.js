'use strict';
/* Catalog Service (port 4001): daftar layanan, harga, promo, dan perhitungan biaya. */
const { createApp, jsonStore, HttpError, clean } = require('../../shared/lib');

const store = jsonStore('catalog', {
  pickup_fee: 10000,
  free_pickup_min: 100000,
  promo: { code: 'KINCLONG10', pct: 10 },
  services: [
    { id: 1, name: 'Fast Clean', price: 25000, days: 1, description: 'Bagian luar dan sol untuk noda ringan.' },
    { id: 2, name: 'Deep Clean', price: 45000, days: 2, description: 'Upper, midsole, insole, dan tali dicuci menyeluruh.' },
    { id: 3, name: 'Suede & Leather Care', price: 65000, days: 3, description: 'Perawatan kulit dan suede dengan bahan khusus.' },
    { id: 4, name: 'Unyellowing', price: 55000, days: 3, description: 'Mengembalikan midsole yang menguning.' },
    { id: 5, name: 'Repaint & Reglue', price: 85000, days: 5, description: 'Cat ulang bagian pudar dan lem sol yang lepas.' },
    { id: 6, name: 'Cuci Tas & Topi', price: 35000, days: 2, description: 'Tas ransel, tote bag, dan topi dicuci dengan hati-hati.' },
    { id: 7, name: 'Anti-Bau & Disinfeksi', price: 20000, days: 1, description: 'Tambahan: hilangkan bau dan bakteri di dalam sepatu.' }
  ]
});

const app = createApp('catalog');

app.get('/services', () => store.read().services);

app.post('/quote', ({ body }) => {
  const db = store.read();
  const service = db.services.find(s => s.id === Number(body.service_id));
  if (!service) throw new HttpError(400, 'Layanan tidak ditemukan.');
  const qty = Number(body.qty);
  if (!Number.isInteger(qty) || qty < 1 || qty > 20) throw new HttpError(400, 'Jumlah sepatu harus 1 sampai 20 pasang.');

  const subtotal = service.price * qty;
  const pickup_fee = body.pickup ? (subtotal >= db.free_pickup_min ? 0 : db.pickup_fee) : 0;
  const promo_valid = clean(body.promo, 20).toUpperCase() === db.promo.code;
  const discount = promo_valid ? Math.round(subtotal * db.promo.pct / 100) : 0;
  return {
    service_id: service.id, service_name: service.name, qty,
    subtotal, pickup_fee, discount, promo_valid,
    total: subtotal - discount + pickup_fee, days: service.days
  };
});

app.listen(process.env.PORT || 4001);
