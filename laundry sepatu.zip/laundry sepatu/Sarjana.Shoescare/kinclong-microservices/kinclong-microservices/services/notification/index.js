'use strict';
/*
 * Notification Service (port 4005): menerima event dari layanan lain dan membuat pesan WhatsApp.
 * Prototype: pesan hanya disimpan (simulasi). Untuk produksi, sambungkan ke WhatsApp Business API / Fonnte / Twilio.
 */
const crypto = require('crypto');
const { createApp, jsonStore, HttpError, reply } = require('../../shared/lib');

const store = jsonStore('notification', { items: [] });
const app = createApp('notification');
const rp = n => 'Rp' + Number(n).toLocaleString('id-ID');
const first = name => String(name || 'Kak').split(' ')[0];

const TEMPLATES = {
  'order.created': d =>
    `Halo ${first(d.name)}, pesanan ${d.code} (${d.service_name} x${d.qty}) sudah kami terima. Total ${rp(d.total)}. Lacak di bagian "Lacak pesanan" di website.`,
  'order.status_changed': d =>
    `Halo ${first(d.name)}, status pesanan ${d.code} sekarang: ${d.status}.`
};

app.post('/events', ({ body }) => {
  const tpl = TEMPLATES[body.type];
  if (!tpl || !body.data) throw new HttpError(400, 'Tipe event tidak dikenal.');
  const db = store.read();
  const item = {
    id: crypto.randomBytes(4).toString('hex'), event: body.type, channel: 'whatsapp (simulasi)',
    to: String(body.data.phone || ''), message: tpl(body.data), at: new Date().toISOString()
  };
  db.items.push(item);
  db.items = db.items.slice(-200);
  store.write(db);
  return reply(201, item);
});

app.get('/admin/notifications', () => store.read().items.slice(-15).reverse());

app.listen(process.env.PORT || 4005);
