'use strict';
/* Review Service (port 4003): ulasan pelanggan dan ringkasan nilai. */
const { createApp, jsonStore, HttpError, reply, clean } = require('../../shared/lib');

const store = jsonStore('review', {
  testimonials: [
    { id: 1, name: 'Rina', rating: 5, message: 'Converse putihku balik seperti baru. Kurirnya juga tepat waktu.', created_at: '2026-08-02T10:00:00.000Z' },
    { id: 2, name: 'Dodi', rating: 5, message: 'Suede aku aman, warnanya tidak luntur. Bakal langganan.', created_at: '2026-08-15T10:00:00.000Z' },
    { id: 3, name: 'Maya', rating: 4, message: 'Hasil bagus, cuma antrean agak panjang saat akhir pekan.', created_at: '2026-09-01T10:00:00.000Z' }
  ]
});
const app = createApp('review');

app.get('/testimonials', () =>
  store.read().testimonials.slice().sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 20));

app.post('/testimonials', ({ body: b }) => {
  const name = clean(b.name, 40), message = clean(b.message, 300), rating = Number(b.rating);
  if (name.length < 2) throw new HttpError(400, 'Nama minimal 2 huruf.');
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw new HttpError(400, 'Nilai harus 1 sampai 5.');
  if (message.length < 10) throw new HttpError(400, 'Ulasan minimal 10 karakter.');
  const db = store.read();
  const t = { id: Math.max(0, ...db.testimonials.map(x => x.id)) + 1, name, rating, message, created_at: new Date().toISOString() };
  db.testimonials.push(t);
  store.write(db);
  return reply(201, t);
});

// Dipakai gateway untuk statistik dashboard admin
app.get('/stats', () => {
  const list = store.read().testimonials;
  const avg = list.length ? list.reduce((s, t) => s + t.rating, 0) / list.length : 0;
  return { count: list.length, avg_rating: Math.round(avg * 10) / 10 };
});

app.listen(process.env.PORT || 4003);
