'use strict';
/*
 * Order Service (port 4002): membuat pesanan, pelacakan, dan pengelolaan admin.
 *  - Memanggil Catalog Service (sinkron) untuk menghitung harga, jadi harga tidak bisa dipalsukan klien.
 *  - Mengirim event ke Notification Service (fire-and-forget): kalau notifikasi mati, pesanan tetap jalan.
 */
const crypto = require('crypto');
const { createApp, jsonStore, call, URLS, HttpError, reply, clean } = require('../../shared/lib');

const STATUSES = ['Diterima', 'Dijemput', 'Dicuci', 'Dikeringkan', 'Siap diambil', 'Selesai'];
const store = jsonStore('order', { orders: [] });
const app = createApp('order');
const fwd = h => ({ 'x-request-id': h['x-request-id'] });

function genCode(orders) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (;;) {
    let c = 'KS-';
    for (let i = 0; i < 6; i++) c += chars[crypto.randomInt(chars.length)];
    if (!orders.some(o => o.code === c)) return c;
  }
}

function notify(type, data, headers) {
  call(URLS.notification, 'POST', '/events', { body: { type, data }, headers: fwd(headers), timeout: 1500 })
    .catch(e => console.warn('[order] notifikasi gagal (diabaikan):', e.message));
}

app.post('/orders', async ({ body: b, headers }) => {
  const name = clean(b.name, 60);
  const phone = String(b.phone || '').replace(/[\s-]/g, '');
  if (name.length < 2) throw new HttpError(400, 'Nama minimal 2 huruf.');
  if (!/^(\+62|62|0)8\d{8,12}$/.test(phone)) throw new HttpError(400, 'Nomor WhatsApp tidak valid. Contoh: 08123456789.');
  const pickup = Boolean(b.pickup);
  const address = clean(b.address, 200);
  if (pickup && address.length < 8) throw new HttpError(400, 'Alamat jemput wajib diisi (minimal 8 karakter).');

  // Panggilan antar-layanan: harga dihitung oleh Catalog Service
  const q = await call(URLS.catalog, 'POST', '/quote', {
    body: { service_id: b.service_id, qty: b.qty, pickup, promo: b.promo }, headers: fwd(headers)
  });

  const db = store.read();
  const now = new Date().toISOString();
  const order = {
    code: genCode(db.orders), name, phone, pickup, address: pickup ? address : '',
    service_id: q.service_id, service_name: q.service_name, qty: q.qty,
    shoe_type: clean(b.shoe_type, 80), notes: clean(b.notes, 300),
    subtotal: q.subtotal, pickup_fee: q.pickup_fee, discount: q.discount, total: q.total,
    status: 'Diterima', history: [{ status: 'Diterima', at: now }], created_at: now
  };
  db.orders.push(order);
  store.write(db);

  notify('order.created', { code: order.code, name, phone, service_name: order.service_name, qty: order.qty, total: order.total }, headers);
  return reply(201, order);
});

// Publik: tanpa telepon & alamat, nama disingkat ke nama depan
app.get('/orders/:code', ({ params }) => {
  const o = store.read().orders.find(x => x.code === params.code.toUpperCase());
  if (!o) throw new HttpError(404, 'Kode pesanan tidak ditemukan.');
  return {
    code: o.code, name: o.name.split(' ')[0], service_name: o.service_name, qty: o.qty,
    pickup: o.pickup, total: o.total, status: o.status, history: o.history
  };
});

/* ---------- Admin (gateway sudah memverifikasi token lewat Auth Service) ---------- */
app.get('/admin/orders', ({ query }) => {
  const status = clean(query.status, 20);
  const q = clean(query.q, 60).toLowerCase();
  return store.read().orders
    .filter(o => !status || o.status === status)
    .filter(o => !q || [o.code, o.name, o.phone].some(v => v.toLowerCase().includes(q)))
    .sort((a, b) => b.created_at.localeCompare(a.created_at));
});

app.get('/admin/stats', () => {
  const orders = store.read().orders;
  const done = orders.filter(o => o.status === 'Selesai');
  return {
    total_orders: orders.length,
    active_orders: orders.length - done.length,
    revenue: done.reduce((s, o) => s + o.total, 0)
  };
});

app.patch('/admin/orders/:code', ({ params, body, headers }) => {
  if (!STATUSES.includes(body.status)) throw new HttpError(400, 'Status tidak valid.');
  const db = store.read();
  const o = db.orders.find(x => x.code === params.code);
  if (!o) throw new HttpError(404, 'Pesanan tidak ditemukan.');
  if (o.status !== body.status) {
    o.status = body.status;
    o.history.push({ status: body.status, at: new Date().toISOString() });
    store.write(db);
    notify('order.status_changed', { code: o.code, name: o.name, phone: o.phone, status: o.status }, headers);
  }
  return o;
});

app.delete('/admin/orders/:code', ({ params }) => {
  const db = store.read();
  const i = db.orders.findIndex(x => x.code === params.code);
  if (i < 0) throw new HttpError(404, 'Pesanan tidak ditemukan.');
  db.orders.splice(i, 1);
  store.write(db);
  return { deleted: true };
});

app.listen(process.env.PORT || 4002);
