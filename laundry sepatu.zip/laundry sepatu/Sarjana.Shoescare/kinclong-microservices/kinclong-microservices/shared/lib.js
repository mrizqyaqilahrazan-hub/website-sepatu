'use strict';
/*
 * Library kecil yang dipakai semua layanan (tanpa dependensi npm, cukup Node 18+):
 *  - createApp   : router HTTP mini + log + pemeriksaan kunci internal
 *  - call        : pemanggil HTTP antar-layanan (timeout, error seragam)
 *  - jsonStore   : penyimpanan file JSON, satu file per layanan (database-per-service)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

const INTERNAL_KEY = process.env.INTERNAL_KEY || 'dev-internal-key';

// Alamat tiap layanan. Di Docker diganti lewat environment (mis. http://order:4002)
const URLS = {
  catalog: process.env.CATALOG_URL || 'http://localhost:4001',
  order: process.env.ORDER_URL || 'http://localhost:4002',
  review: process.env.REVIEW_URL || 'http://localhost:4003',
  auth: process.env.AUTH_URL || 'http://localhost:4004',
  notification: process.env.NOTIFICATION_URL || 'http://localhost:4005'
};

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const reply = (status, data) => ({ __reply: true, status, data });
const clean = (v, max) => String(v ?? '').trim().replace(/\s+/g, ' ').slice(0, max);

function readBody(req, limit = 50 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0, tooBig = false;
    req.on('data', c => { size += c.length; if (size > limit) tooBig = true; else chunks.push(c); });
    req.on('end', () => (tooBig ? reject(new HttpError(413, 'Data terlalu besar.')) : resolve(Buffer.concat(chunks))));
    req.on('error', reject);
  });
}

/* ---------- Server layanan ---------- */
function createApp(name) {
  const routes = [];
  const add = (method, pattern, handler) => {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:([a-zA-Z_]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
    routes.push({ method, re, keys, handler });
  };

  const app = {
    get: (p, h) => add('GET', p, h),
    post: (p, h) => add('POST', p, h),
    patch: (p, h) => add('PATCH', p, h),
    delete: (p, h) => add('DELETE', p, h),
    listen(port) {
      const server = http.createServer(async (req, res) => {
        const t0 = Date.now();
        const url = new URL(req.url, 'http://x');
        let status = 200;
        const send = (s, data) => {
          status = s;
          const b = JSON.stringify(data);
          res.writeHead(s, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(b) });
          res.end(b);
        };
        try {
          // Hanya gateway / layanan lain yang boleh memanggil (kecuali /health)
          if (url.pathname !== '/health' && req.headers['x-internal-key'] !== INTERNAL_KEY) {
            throw new HttpError(403, 'Akses langsung ke layanan internal ditolak. Lewat gateway.');
          }
          let params = {};
          const route = routes.find(r => {
            if (r.method !== req.method) return false;
            const m = r.re.exec(url.pathname);
            if (!m) return false;
            r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
            return true;
          });
          if (!route) throw new HttpError(404, 'Endpoint tidak ditemukan.');

          let body = {};
          if (['POST', 'PATCH', 'PUT'].includes(req.method)) {
            const raw = await readBody(req);
            if (raw.length) { try { body = JSON.parse(raw); } catch { throw new HttpError(400, 'Format JSON tidak valid.'); } }
          }
          const out = await route.handler({
            params, query: Object.fromEntries(url.searchParams),
            body: body && typeof body === 'object' ? body : {}, headers: req.headers
          });
          if (out && out.__reply) send(out.status, out.data);
          else send(200, out === undefined ? { ok: true } : out);
        } catch (e) {
          const s = e.status || 500;
          if (s === 500) console.error(`[${name}]`, e);
          send(s, { error: s === 500 ? 'Terjadi kesalahan di server.' : e.message });
        }
        console.log(`[${name}] ${req.method} ${url.pathname} ${status} ${Date.now() - t0}ms ${req.headers['x-request-id'] || ''}`);
      });
      server.listen(port, () => console.log(`[${name}] siap di port ${port}`));
      return server;
    }
  };

  app.get('/health', () => ({ ok: true, service: name }));
  return app;
}

/* ---------- Pemanggil antar-layanan ---------- */
async function call(base, method, pathname, { body, headers = {}, timeout = 3000 } = {}) {
  const h = { 'content-type': 'application/json', 'x-internal-key': INTERNAL_KEY };
  for (const [k, v] of Object.entries(headers)) if (v !== undefined && v !== null && v !== '') h[k] = v;
  let res;
  try {
    res = await fetch(base + pathname, {
      method, headers: h, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(timeout)
    });
  } catch {
    throw new HttpError(503, 'Layanan pendukung sedang tidak tersedia. Coba lagi nanti.');
  }
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { /* bukan JSON */ }
  if (!res.ok) throw new HttpError(res.status, (data && data.error) || 'Layanan mengembalikan error ' + res.status);
  return data;
}

/* ---------- Penyimpanan JSON (satu file per layanan) ---------- */
function jsonStore(name, seed) {
  const dir = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
  const file = path.join(dir, name + '.json');
  fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(seed, null, 2));
  return {
    read: () => JSON.parse(fs.readFileSync(file, 'utf8')),
    write: data => {
      const tmp = file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
      fs.renameSync(tmp, file); // tulis atomik
    }
  };
}

module.exports = { createApp, call, jsonStore, HttpError, reply, clean, readBody, URLS, INTERNAL_KEY };
